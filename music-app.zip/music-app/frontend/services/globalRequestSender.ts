import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';

// Define the base URL of your API
const baseURL = process.env.NEXT_PUBLIC_BASE_URL;


// Create an Axios instance with default configuration
const api = axios.create({
  baseURL,
});


// Function to set the authorization header with the token
const setAuthToken = (token: string | null) => {
  if (token) {
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  } else {
    delete api.defaults.headers.common['Authorization'];
  }
};

// Interceptor to add authorization header to outgoing requests
api.interceptors.request.use(
  (config: AxiosRequestConfig) => {
    const token = localStorage.getItem('token'); // Assuming token is stored in localStorage
    setAuthToken(token);
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Interceptor to handle API responses
api.interceptors.response.use(
  (response: AxiosResponse) => {
    return response;
  },
  (error) => {
    // Handle error responses here (e.g., token expiration, unauthorized access, etc.)
    return Promise.reject(error);
  }
);

// Function to handle API requests
const globalRequestSender = async <T>(
  method: 'GET' | 'POST' | 'DELETE' | 'PUT',
  url: string,
  data?: any,
  config?: AxiosRequestConfig
): Promise<T> => {

  console.log("url", url)
  try {
    const response: AxiosResponse<T> = await api.request<T>({
      url,
      method,
      data,
      ...config,
    });
    return response.data;
  } catch (error) {
    // Handle errors here (e.g., logging, error messages, etc.)
    throw error;
  }
};

// // Usage example
// const fetchData = async () => {
//   try {
//     const data = await globalRequestSender<MyDataType>('GET', '/endpoint');
//     console.log(data);
//   } catch (error) {
//     console.error('Error fetching data:', error);
//   }
// };

// // Define types/interfaces for your API response data
// interface MyDataType {
//   // Define the structure of your data
// }

export default globalRequestSender;
