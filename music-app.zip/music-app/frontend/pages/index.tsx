import Image from "next/image";
import { Inter } from "next/font/google";
import { useEffect, useState } from "react";
import { useUser } from "@auth0/nextjs-auth0/client";
import Layout from "@/components/Layout";
import HomePage from "@/containers/homePage";


import Spinner from "@/components/Common/Spinner";
import Slider from "@/components/Common/Slider/Slider";
import { useAppDispatch, useAppSelector } from "@/hooks/redux";
import { setAuthDetails } from "@/store/authSlice";
const inter = Inter({ subsets: ["latin"] });

export default function Home() {
  const dispatch = useAppDispatch;
  const [singleSong, setSingleSong] = useState({});

  const { authDetails } = useAppSelector((state) => state.AuthReducer);
  const { user, error, isLoading } = useUser();

  // useEffect(() => {
  //   if (user) {
  //     // const { name, picture, email } = user;
  //     dispatch(setAuthDetails(user));
  //   }
  // }, [user]);

  const fetchSingleSong = async () => {
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}music/get-single-music-file/65c3dccfc0d8819bcbf83474`,
        {
          method: "GET",
        }
      );

      // const res= await axios.get(`${process.env.NEXT_PUBLIC_BASE_URL}music/get-single-music-file/${songId}`)

      const data = await res.json();
      console.log("data", data);
      console.log(" data ===", data);
      setSingleSong(data);
      // dispatch(setSongPlayer(true));
      // if (data) {
      //   const vidoeSongs = data.songs.filter((song: any) => {
      //     return song.metadata.fileType === "video";
      //   });
      //   setVidoes(vidoeSongs);
      //   const audioSongs = data.songs.filter((song: any) => {
      //     return song.metadata.fileType === "audio";
      //   });
      //   setAudios(audioSongs);
      // }
    } catch (err) {
      console.log(err);
    }
  };
  useEffect(()=>{
    fetchSingleSong()
  },[])
  if (isLoading) return <Spinner />;
  if (error) return <div>{error.message}</div>;

  if (user) {
    return (
      <div className="text-[#fff]">
        {/* <button className="border border-red-800">
        <a href="/api/auth/logout" className="">Logout jhjhjh</a>
        </button> */}
        Welcome {user.name}! <a href="/api/auth/logout" className="block border">Logout</a>
      </div>
    );
  }


  interface MusicData {
    fileBase64String: string;
    metadata: {
      filename: string;
      fileType: string;
    };
  }

  const contentRender = (data: any) => {
    if (data.metadata.fileType === "image") {
      return (
        <img
          key={data.metadata.filename} // Ensure each element has a unique key
          src={`data:image/jpg;base64,${data.fileBase64String}`}
          alt={data.metadata.filename}
          height={300}
          width={300}
        />
      );
    } else if (data.metadata.fileType === "video") {
      return (
        <video
          key={data.metadata.filename} // Ensure each element has a unique key
          height={300}
          width={300}
          controls // Add controls for the video player
        >
          <source
            src={`data:video/mp4;base64,${data.fileBase64String}`}
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>
      );
    } else {
      return (
        <audio
          key={data.metadata.filename} // Ensure each element has a unique key
          controls // Add controls for the audio player
        >
          <source
            src={`data:audio/mp4;base64,${data.fileBase64String}`}
            type="audio/mp4"
          />
          Your browser does not support the audio tag.
        </audio>
      );
    }
  };



  const sliderSettings = {
    slidesPerView: 6,
    slidesPerSlide: 3,
    space: 50,
  };
 
  return (
    <Layout>
      <main
        className={` w-[100%] px-10 py-[30px] lg:p-24`}
      >
        <HomePage fav={true}/>
    
        {/* <h1>music app</h1> */}
        {/* <a href="/api/auth/login">login</a> */}
        {/* {files?.songs?.map((data: any) => {
          return contentRender(data);
        })} */}
{/* {
  contentRender(singleSong)
} */}


        {/* <Slider data={files} sliderSettings={sliderSettings} /> */}
      </main>
    </Layout>
  );
}
