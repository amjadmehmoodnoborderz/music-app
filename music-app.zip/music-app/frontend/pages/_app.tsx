// pages/_app.js
import "../styles/globals.css";
// import Auth0ProviderWithHistory from '../utils/auth0.js';
// import "antd/dist/antd.css";

import { UserProvider } from "@auth0/nextjs-auth0/client";
import type { AppProps } from "next/app";
import { Provider } from "react-redux";

import { store } from "@/store/store";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
function MyApp({ Component, pageProps }: AppProps) {
  const [color, setColor]= useState("")

  // console.log("color",color)
  // const generateRandomColor = () => {
  //   const newColor='#' + Math.floor(Math.random()*16777215).toString(16);
  //   setColor(newColor)
  // }

  // useEffect(() => {
  //   const interval = setInterval(() => {
  //     generateRandomColor();
  //     // setColor(color);
  //   }, 3000);

  //   return () => clearInterval(interval);
  // }, []);

  return (
    
    <UserProvider>
      <Provider store={store}>
        <div className="w-[100%] z-[1] h-[100%]  relative  bg-[#030303]">
          <div  className="fixed border-[2px] top-[-100px] bg-[#288cff34] left-[100px] w-[600px] h-[400px] box-shadow rounded-full blur-[200px] "></div>
          <div className="fixed  border-[2px]  bottom-[0px] right-[-220px] w-[600px] h-[700px] box-shadow rounded-full blur-[200px] bg-[#ff11111a]"></div>
         <Component {...pageProps} />

         
        </div>

        {/* <Layout> */}

        {/* </Layout> */}
      </Provider>
    </UserProvider>
  );
}

export default MyApp;
