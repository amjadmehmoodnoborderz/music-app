import React, { useEffect, useState } from "react";
import Layout from "@/components/Layout";
import dynamic from "next/dynamic";
const MyFavourite = dynamic(() => import('@/containers/myFavourite'), { ssr: false })

const index = () => {

  return (
    <Layout>
      <div className={` w-[100%] px-10 py-[30px] lg:p-24`}>
        <MyFavourite fav={false} />
      </div>
    </Layout>
  );
};

export default index;
