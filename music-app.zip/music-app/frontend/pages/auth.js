import React from "react";
import Auth from "@/containers/auth"
import {checkoutLoggedIn} from "@/hooks/checkoutLoggedIn"
const login = () => {
  checkoutLoggedIn()
  return (
    <div className="max-w-[500px] px-2 mx-auto flex justify-center items-center h-[100vh]">
      <Auth/>
    </div>
  );
};
export default login
