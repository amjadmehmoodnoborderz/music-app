import { useAppDispatch } from "@/hooks/redux";
import globalRequestSender from "@/services/globalRequestSender";
import { setAuthDetails } from "@/store/authSlice";
import { Divider, message } from "antd";
import { register } from "module";
import { useRouter } from "next/router";
import React, { useEffect, useState } from "react";
import { FiMail } from "react-icons/fi";
import { IoLockClosedOutline } from "react-icons/io5";
import SocialLogins from "@/components/Common/SocialLogins"
interface LoginDataType {
  email: string;
  password: string;
  success: boolean;
  msg: "";
  user:{email:string, username:string, _id:string, __v:number}
  // Define the structure of your data
}

interface RegisterDataType {
  email: string;
  password: string;
  username: "";
  success: boolean;
  msg: "";
  // Define the structure of your data
}

const Auth = () => {
  const [isRegistering, setIsRegistering] = useState(true);
const dispatch= useAppDispatch()
  console.log("isRegistering", isRegistering);
  const [messageApi, contextHolder] = message.useMessage();
  const [isLoading, setIsloading] = useState(false);
  const [authData, setAuthData] = useState({
    email: "",
    password: "",
    username: "",
  });
  const router = useRouter();

  // Function to handle setting query parameters
  const setQueryParams = (params: any) => {
    router.push({
      pathname: router.pathname,
      query: params,
    });
  };

  const clearForm = () => {
    setAuthData({
      email: "",
      password: "",
      username: "",
    });
  };

  useEffect(() => {
    if (typeof isRegistering !== "undefined") {
      const queryParams = isRegistering
        ? { register: "true" }
        : { login: "true" };
      setQueryParams(queryParams);
    }
  }, [isRegistering]);

  const handleLogin = async () => {
    try {
      if (isRegistering) {
        setIsloading(true);
        const response = await globalRequestSender<RegisterDataType>(
          "POST",
          "auth/create-user",
          authData
        );

        if (response && response.success) {
          setIsloading(false);
          clearForm();
          setIsRegistering(false);
          console.log("response.success", response);

          messageApi.open({
            type: "success",
            content: response.msg,
          });
        } else {
          messageApi.open({
            type: "error",
            content: "Something went wronge while creating account",
          });
        }
        return;
      }
      const response = await globalRequestSender<LoginDataType>(
        "POST",
        "auth/login-user",
        authData
      );

      if(response && response.success) {
        router.push("/");
        dispatch(setAuthDetails(response.user))
        localStorage.setItem("user",JSON.stringify(response.user) )
        messageApi.open({
          type: "success",
          content: response.msg,
        });
        return
      } else {
        messageApi.open({
          type: "error",
          content: "Something went wronge while loging in",
        });

        return
      }
    } catch (error) {
      console.log(error);
      setIsloading(false);
      messageApi.open({
        type: "error",
        content: "Something went wronge while",
      });

      return
    }
  };

  //   if (isRegistering) {
  //     // Ensure that hooks are called unconditionally
  //     // If Register component requires hooks, they should be called within Register component itself
  //     return Register(setIsRegistering);
  //   }
  return (
    <div className="relative z-[9999] max-[100%] flex-grow border-[1px] rounded-[8px] py-[20px] px-[20px] border-[rgba(255,255,255,0.15)]">
      <div className="h-[40px] relative flex w-[100%] rounded-[8px]">
        <FiMail className="absolute text-[#e2e0e0a2] text-[20px] top-[50%] left-[20px] translate transform translate-x-[-50%] translate-y-[-50%] " />
        <input
          type="text"
          className="h-[100%] relative pl-[40px] border-[1px] rounded-[8px] border-[rgba(255,255,255,0.15)] text-[16px] text-[#fff] font-[400] placeholder-[#e2e0e0a2] placeholder-opacity-100  bg-[rgba(255,255,255,.15)] outline-none overflow-hidden w-[100%] px-[20px]"
          placeholder="Enter email..."
          name="email"
          onChange={(e) =>
            setAuthData({ ...authData, [e.target.name]: e.target.value })
          }
        />
      </div>
      {isRegistering && (
        <div className="h-[40px] relative mt-[20px] flex w-[100%] rounded-[8px]">
          <IoLockClosedOutline className="absolute text-[#e2e0e0a2] text-[20px] top-[50%] left-[20px] translate transform translate-x-[-50%] translate-y-[-50%] " />
          <input
            type="text"
            className="h-[100%] relative pl-[40px] border-[1px] rounded-[8px] border-[rgba(255,255,255,0.15)] text-[16px] text-[#fff] font-[400] placeholder-[#e2e0e0a2] placeholder-opacity-100  bg-[rgba(255,255,255,.15)] outline-none overflow-hidden w-[100%] px-[20px]"
            placeholder="Enter username..."
            value={authData.username}
            name="username"
            onChange={(e) =>
              setAuthData({
                ...authData,
                [e.target.name]: e.target.value,
              })
            }
          />
        </div>
      )}
      <div className="h-[40px] relative mt-[20px] flex w-[100%] rounded-[8px]">
        <IoLockClosedOutline className="absolute text-[#e2e0e0a2] text-[20px] top-[50%] left-[20px] translate transform translate-x-[-50%] translate-y-[-50%] " />
        <input
          type="text"
          className="h-[100%] relative pl-[40px] border-[1px] rounded-[8px] border-[rgba(255,255,255,0.15)] text-[16px] text-[#fff] font-[400] placeholder-[#e2e0e0a2] placeholder-opacity-100  bg-[rgba(255,255,255,.15)] outline-none overflow-hidden w-[100%] px-[20px]"
          placeholder="Enter Password..."
          name="password"
          onChange={(e) =>
            setAuthData({ ...authData, [e.target.name]: e.target.value })
          }
        />
      </div>

      <button
        onClick={handleLogin}
        className="bg-[#030303] rounded-[8px] mt-[20px] cursor-pointer text-[#e2e0e0a2] w-[100%] py-[10px]"
      >
        {isLoading
          ? "Loading"
          : !isLoading && isRegistering
          ? "Create account"
          : "Login"}
      </button>
      {!isRegistering && (
        <>
          {/* <Divider className="text-[#e2e0e0a2]">
            <span className="text-[#e2e0e0a2]">OR</span>
          </Divider> */}

          {/* <SocialLogins/> */}
          {/* <div className="">
            <button  className="bg-transparant border-[1px] rounded-[8px] border-[rgba(255,255,255,0.15)] mt-[20px] cursor-pointer text-[#e2e0e0a2] w-[100%] py-[10px]">
              <a href="/api/auth/login">
              Go with google
              </a>
             
            </button>
            <button className="bg-transparant border-[1px] rounded-[8px] border-[rgba(255,255,255,0.15)] mt-[20px] cursor-pointer text-[#e2e0e0a2] w-[100%] py-[10px]">
              Go with facebook
            </button>
          </div> */}
        </>
      )}

      <p
        onClick={() => setIsRegistering((prev) => !prev)}
        className=" cursor-pointer justify-center flex w-[100%] border mt-[20px] text-center text-[#e2e0e0a2]"
      >
        {isRegistering ? " Already have account?" : "Want to create accout?"}.
        Click here
      </p>
    </div>
  );
};

export default Auth;
