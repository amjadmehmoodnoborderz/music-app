import { useAppDispatch, useAppSelector } from "@/hooks/redux";
import { setSongPlayer } from "@/store/uploaderOpenerSlice";
import React, { useEffect, useRef, useState } from "react";
import { IoMdPlay } from "react-icons/io";
import dynamic from "next/dynamic";
const SongPlayer = dynamic(() => import('../../components/SongPlayer/'), { ssr: false })
// import CategoriesWrapper from "../../components/CategoriesWrapper";
const Audios = dynamic(() => import('../../components/Audios/'), { ssr: false })
const Vidoes = dynamic(() => import('../../components/Vidoes/'), { ssr: false })

import axios from "axios";
import { setAudios, setVidoes } from "@/store/musicSlice";
const index = ({fav}:any) => {

  const [singleSong, setSingleSong] = useState({});
  const [songId, setSongId] = useState(null);
  const [loading, setLoading] = useState(false);
  const dispatch = useAppDispatch();
  const { authDetails } = useAppSelector((state: any) => state.AuthReducer);
  const {videoSongs,audioSongs}= useAppSelector((state:any)=>state.musicReducer)
  console.log("videoSongs20", videoSongs);

  const fetchFiles = async () => {
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}music/get-my-favourite-music/${authDetails.favouriteSongs}`,
        {
          method: "GET",
        }
      );
  
   
      const data = await res.json();
      console.log("data.songs", data.songs)
      if (data) {
        const vidoeSongs = data.songs.filter((song: any) => {
          return song.metadata.fileType === "video";
        });
        // setVidoes(vidoeSongs);
        console.log("vidoeSongs", vidoeSongs)

        dispatch(setVidoes(vidoeSongs));

        const audioSongs = data.songs.filter((song: any) => {
          return song.metadata.fileType === "audio";
        });
        console.log("audioSongs", audioSongs)

        dispatch(setAudios(audioSongs));

      }

      // Further handling of response data
    } catch (err) {
      console.log(err);
    }
  };
  
  const fetchSingleSong = async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}music/get-single-music-file/${songId}`,
        {
          method: "GET",
        }
      );

      // const res= await axios.get(`${process.env.NEXT_PUBLIC_BASE_URL}music/get-single-music-file/${songId}`)

      const data = await res.json();
      console.log("data", data);
      console.log(" data ===", data);
      setSingleSong(data);
      setLoading(false);
      // if (data) {
      //   const vidoeSongs = data.songs.filter((song: any) => {
      //     return song.metadata.fileType === "video";
      //   });
      //   setVidoes(vidoeSongs);
      //   const audioSongs = data.songs.filter((song: any) => {
      //     return song.metadata.fileType === "audio";
      //   });
      //   setAudios(audioSongs);
      // }
    } catch (err) {
      console.log(err);
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchFiles();
  }, []);

  useEffect(() => {
    if (songId) {
      fetchSingleSong();
    } else {
      setSingleSong({});
    }
  }, [songId]);

 
  return (
    <>
      <SongPlayer
        loading={loading}
        singleSong={singleSong}
        setSongId={setSongId}
      />
         {/* <CategoriesWrapper/> */}
      <div className=" w-[100%] h-[100%] relative ">
        <div className="flex justify-start items-center gap-[15px]">
          <div className="w-[50px] z-[1] text-[24px]  flex justify-center items-center h-[50px] rounded-full text-[#fff] bg-[#00887A]">
            {authDetails?.username?.at(0).toUpperCase()}
          </div>
          <div>
            <p className="text-[#fff] -z-[1] uppercase">{authDetails?.username}</p>
            <p className="text-[#fff] -z-[1] text-[30px] font-[700]">Listen again</p>
          </div>
        </div>

        <Vidoes vidoes={videoSongs} fav={fav} setSongId={setSongId}/>

     

        <div className="py-[20px]">
          <p className="text-[#fff] text-[20px]">Audio music</p>
        </div>

        <div className="w-[100%]">

          <Audios audios={audioSongs}/>
          {/* {audios?.map((audio, index) => {
            return (
              <audio
                ref={audioRef}
                className="w-[100%] mb-[20px]"
                key={audio.metadata.filename} // Ensure each element has a unique key
                controls // Add controls for the audio player
              >
                <source
                  src={`data:audio/mp4;base64,${audio.fileBase64String}`}
                  type="audio/mp4"
                />
                Your browser does not support the audio tag.
              </audio>
            );
          })} */}
        </div>
      </div>
    </>
  );
};

export default index;
