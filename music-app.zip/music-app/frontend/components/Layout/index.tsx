import React, { useEffect, useState } from "react";
import NavBar from "../NavBar";
import SideBar from "../SideBar";
import UploaderOpener from "../Uploader";

import { Modal } from "antd";
import {  useRouter } from "next/router";

interface NavBarProps {
  scrolled: boolean;
}
const index = ({ children }:any) => {
  const [scrolled, setScrolled] = useState<boolean>(false);
  const [isAuthenticated, setIsAuthenticated] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    // Clean up the event listener
    return () => {
      window.removeEventListener("scroll", handleScroll);
    }
  },[]);

  const handleOk = () => {
    router.push("/auth");
  };

  return (
    <div className="w-[100%] flex items-center relative min-h-[100vh] max-w-[1800px] mx-auto">
          <Modal
        title="You need login first, go to login"
        open={!isAuthenticated}
        onOk={handleOk}
        onCancel={() => setIsAuthenticated(true)}
      ></Modal>
        {/* <div className="mt-[20px] px-[20px] "> */}
      {/* <LogWrapper/> */}
      {/* </div> */}
        <SideBar setIsAuthenticated={setIsAuthenticated}/>
      <div
        className={`grow lg:ml-[250px]  w-[calc(100%-250px)]  h-[100%]  
        }]`}
      >
        <UploaderOpener/>
        <NavBar scrolled={scrolled} />
        <div className="relative  w-[100%] h-[100%] ">
       
          {children}
        </div>
      </div>
    
    </div>
  );
};

export default index;
