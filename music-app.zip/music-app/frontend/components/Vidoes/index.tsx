import { useAppDispatch, useAppSelector } from "@/hooks/redux";
import globalRequestSender from "@/services/globalRequestSender";
import { setAuthDetails } from "@/store/authSlice";
import { setSongPlayer } from "@/store/uploaderOpenerSlice";
import React, { useState } from "react";
import { IoMdPlay } from "react-icons/io";
import { IoBookmarks, IoBookmarksOutline } from "react-icons/io5";

const index = ({ vidoes, setSongId,fav }: any) => {
  const dispatch = useAppDispatch();
  const { authDetails } = useAppSelector((state: any) => state.AuthReducer);
  const handleFavourite = async (songId: string) => {
    if (!authDetails) {
      alert("you need to login");
      return;
    }

    try {
      const res: any = await globalRequestSender(
        "PUT",
        `auth/add-favourite-song/${authDetails._id}/${songId}`
      );
      if (res && res.success) {
    
        let updatedAuthDetails;
        const isFavorite = authDetails.favouriteSongs.includes(songId);

        if (isFavorite) {
          updatedAuthDetails = {
            ...authDetails,
            favouriteSongs: authDetails.favouriteSongs.filter(
              (id:string) => id !== songId
            ),
          };
        } else {
          updatedAuthDetails = {
            ...authDetails,
            favouriteSongs: [...authDetails.favouriteSongs, songId],
          };
        }

        localStorage.setItem("user", JSON.stringify(updatedAuthDetails));
        dispatch(setAuthDetails(updatedAuthDetails));
      }
    } catch (error) {
      console.log(error);
    }
  };
  const [isHover, setIsHovered] = useState("");
  return (
    <div className="mt-[10px] pb-[100px]  w-[100%] h-[100%] gap-[20px] overflow-x-auto flex ">
      {vidoes &&
        vidoes.map((video: any, index: number) => {
          //   console.log("video", video?.songDetails);
          return (
            <div
              onMouseEnter={() => setIsHovered(video?.songDetails.songId)}
              onMouseLeave={() => setIsHovered("")}
              className="cursor-pointer w-[235px]  min-w-[235px]  relative h-[132px] "
            >
              <div
                onClick={() => {
                  dispatch(setSongPlayer(true));
                  setSongId(video?.songDetails.songId);
                }}
                className="w-[100%] h-[100%] relative  cursor-pointer"
              >
                <IoMdPlay className="absolute cursor-pointer text-[50px] text-[#fff] mx-auto top-[50%] left-[50%] translate-y-[-50%]  translate-x-[-50%] " />
              {video?.songDetails?.thumbnail?.thumbnail?
                <img
                  src={`data:image/jpg;base64,${video?.songDetails?.thumbnail?.thumbnail}`}
                  className="w-[100%] h-[100%] object-cover "
                />:<div className="bg-[#ffe134] w-[100%] h-[100%]">

                </div>
              }
              </div>
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-[#fff] text-[16px] font-[500] capitalize mt-[10px]">
                    {video.songDetails.songName}
                  </p>
                  <p className="text-[#AFAFAF] text-[16px] font-[500] capitalize mt-[0px]">
                    {video.songDetails.singerName}
                  </p>
                </div>
                {fav &&isHover === video?.songDetails.songId &&
                  (authDetails.favouriteSongs.includes(
                    video?.songDetails.songId
                  ) ? (
                    <IoBookmarks
                      onClick={() => handleFavourite(video?.songDetails.songId)}
                      className="text-[#fff] text-[20px]"
                    />
                  ) : (
                    <IoBookmarksOutline
                      onClick={() => handleFavourite(video?.songDetails.songId)}
                      className="text-[#fff] text-[20px]"
                    />
                  ))}
              </div>

              {/* <video
          key={data.metadata.filename} // Ensure each element has a unique key
          height={300}
          width={300}
          controls // Add controls for the video player
        >
          <source
            src={`data:video/mp4;base64,${data.fileBase64String}`}
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video> */}
            </div>
          );
        })}
    </div>
  );
};

export default index;
