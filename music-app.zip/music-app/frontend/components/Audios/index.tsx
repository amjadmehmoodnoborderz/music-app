import React, { useState, useRef, useEffect } from "react";
import { IoIosPause } from "react-icons/io";
import { IoPlay } from "react-icons/io5";

const AudioPlayer = ({ audios }) => {
    const [isPlaying, setIsPlaying] = useState(false);
    const [currentAudioIndex, setCurrentAudioIndex] = useState(null); // Initialize to null
    const [volume, setVolume] = useState(1);
    const [duration, setDuration] = useState(0);
    const [currentTime, setCurrentTime] = useState(0);
    const circleRadius = 30; // Increased radius for better visibility
    const circleCircumference = 2 * Math.PI * circleRadius;
  
    useEffect(() => {
      const handleLoadedMetadata = () => {
        const audioElement = document.getElementById(`audio-${currentAudioIndex}`);
        if (audioElement) {
          setDuration(audioElement.duration);
        }
      };
    
      const handleTimeUpdate = () => {
        const audioElement = document.getElementById(`audio-${currentAudioIndex}`);
        if (audioElement) {
          setCurrentTime(audioElement.currentTime);
        }
      };
    
      if (currentAudioIndex !== null) {
        handleLoadedMetadata();
        handleTimeUpdate();
        const audioElement = document.getElementById(`audio-${currentAudioIndex}`);
        if (audioElement) {
          audioElement.addEventListener("loadedmetadata", handleLoadedMetadata);
          audioElement.addEventListener("timeupdate", handleTimeUpdate);
          return () => {
            audioElement.removeEventListener("loadedmetadata", handleLoadedMetadata);
            audioElement.removeEventListener("timeupdate", handleTimeUpdate);
          };
        }
      }
    }, [currentAudioIndex]);
  
    const playAudio = (index) => {
      setCurrentAudioIndex(index);
  
      const audioElement = document.getElementById(`audio-${index}`);
  
      if (!audioElement) {
        console.error(`Audio element not found for index ${index}`);
        return;
      }
  
      if (index === currentAudioIndex) {
        if (!isPlaying) {
          audioElement.play();
          setIsPlaying(true);
        } else {
          audioElement.pause();
          setIsPlaying(false);
        }
      } else {
        const currentAudioElement = document.getElementById(`audio-${currentAudioIndex}`);
        if (currentAudioElement && isPlaying) {
          currentAudioElement.pause();
          setIsPlaying(false);
        }
        audioElement.play();
        setIsPlaying(true);
      }
    };
  
    const formatTime = (timeInSeconds) => {
      const minutes = Math.floor(timeInSeconds / 60);
      const seconds = Math.floor(timeInSeconds % 60);
      return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
    };
  
    const progress = duration > 0 ? (currentTime / duration) * circleCircumference : 0;
  

  return (
    <>
      {audios?.length > 0 && (
        <div className="bg-[#232831] flex flex-col gap-[10px] rounded-[10px] p-[10px]">
          {audios.map((audio, index) => {
            console.log("audio", audio);
            return (
              <div
                key={audio.metadata.filename}
                onClick={() => playAudio(index)}
                className={` cursor-pointer flex justify-between items-center ${
                  currentAudioIndex === index && "bg-[#2C333F]"
                } hover:bg-[#2C333F] rounded-[10px] p-[10px]`}
              >
                <div className="flex justify-start gap-[15px]">
                {/* <div className="set-size charts-container">
  <div className="pie-wrapper progress-30 p-[10px] w-[40px] relative h-[40px]">
  <div className="w-[100%] h-[100%]  relative flex overflow-hidden justify-center items-center bg-blue-500 rounded-full">
                    <img
                      src={`data:image/jpg;base64,${audio?.songDetails?.thumbnail?.thumbnail}`}
                      className="w-[90%] relative  h-[90%] object-cover "
                    />
                    {currentAudioIndex === index && isPlaying ? (
                      <IoIosPause className="z-[9999] text-[20px] text-[#fff] absolute " />
                    ) : (
                      <IoPlay className="z-[9999] text-[#fff] text-[20px] absolute"  />
                    )}
                  </div>
    <span className="label">30<span className="smaller">%</span></span>
    <div className="pie">
      <div className="left-side half-circle" />
      <div className="right-side half-circle" />
    </div>
  </div>
</div> */}

                  <div className="w-[30px] relative h-[30px] flex overflow-hidden justify-center items-center bg-blue-500 text-white rounded-full">
                    <img
                      src={`data:image/jpg;base64,${audio?.songDetails?.thumbnail?.thumbnail}`}
                      className="w-[100%] h-[100%] object-cover "
                    />
                    {currentAudioIndex === index && isPlaying ? (
                      <IoIosPause className="z-[9999] absolute " />
                    ) : (
                      <IoPlay className="z-[9999] absolute"  />
                    )}
                  </div>
                  <span className="text-[#FFFFFF] text-[16px] text-left">
                    {audio?.songDetails?.songName}
                  </span>
                </div>
                <span className="text-[#FFFFFF] text-[16px] font-[400]">{formatTime(duration)}</span>
                <audio
                  id={`audio-${index}`}
                  className="w-full mt-2"
                  controls={false}
                //   onEnded={handleAudioEnded}
                  volume={volume}
                >
                  <source
                    src={`data:audio/mp4;base64,${audio.fileBase64String}`}
                    type="audio/mp4"
                  />
                  Your browser does not support the audio tag.
                </audio>
              </div>
            );
          })}
        </div>
      )}
    </>
  );
};

export default AudioPlayer;
