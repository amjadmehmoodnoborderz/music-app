import { useAppDispatch, useAppSelector } from "@/hooks/redux";
import { setSongPlayer } from "@/store/uploaderOpenerSlice";
import { Drawer, Slider } from "antd";
import React, { useState, useRef, useEffect } from "react";
import { IoPauseCircleOutline, IoPlayCircleOutline } from "react-icons/io5";

const Index = ({ singleSong, loading, setSongId }) => {
  const dispatch = useAppDispatch();
  const [isPlaying, setIsPlaying] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [volume, setVolume] = useState(1);
  const [progress, setProgress] = useState(0);
  const videoRef = useRef(null);
  const { songPlayer } = useAppSelector((state: any) => state.UploaderReducer);
  const togglePlayPause = () => {
    setIsPlaying((prevState) => !prevState);
    if (videoRef.current.paused) {
      videoRef.current.play();
    } else {
      videoRef.current.pause();
    }
  };

  const handleVolumeChange = (event) => {
    const volume = event.target.value;
    setVolume(volume);
    videoRef.current.volume = volume;
  };

  const handleProgress = () => {
    const currentTime = videoRef.current.currentTime;
    const duration = videoRef.current.duration;
    const progress = (currentTime / duration) * 100;
    setProgress(progress);
  };

  const handleSeek = (event) => {
    console.log("event", event.nativeEvent.offsetX, event.target.offsetWidth);
    const seekTime =
      (event.nativeEvent.offsetX / event.target.offsetWidth) *
      videoRef.current.duration;
    videoRef.current.currentTime = seekTime;
  };

  const onClose = () => {
    dispatch(setSongPlayer(false));
    setSongId(null);
  };

  return (
    <Drawer
      title="Upload your music"
      width={900}
      onClose={onClose}
      open={songPlayer}
      styles={{
        body: {
          paddingBottom: 80,
        },
      }}
    >
      {loading ? (
        <>
          <div className="skeleton-loading animate-pulse">
            <div className="w-full h-96 bg-gradient-to-b from-gray-300 via-gray-200 to-gray-300 "></div>
          </div>
          <div className="skeleton-loading mt-[10px] animate-pulse">
            <div className="w-full h-10 bg-gradient-to-b from-gray-300 via-gray-200 to-gray-300 "></div>
          </div>
          <div className="skeleton-loading mt-[10px] animate-pulse">
            <div className="w-[200px] h-10 bg-gradient-to-b from-gray-300 via-gray-200 to-gray-300 "></div>
          </div>
          <div className="skeleton-loading mt-[10px] animate-pulse">
            <div className="w-full h-[300px] bg-gradient-to-b from-gray-300 via-gray-200 to-gray-300 "></div>
          </div>
        </>
      ) : (
        <>
          <div
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            className="w-[100%] relative  cursor-pointer"
          >
            <video
              ref={videoRef}
              key={singleSong.metadata}
              className="w-[100%] h-[100%]"
              autoPlay
              loop
              controls={false}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              onTimeUpdate={handleProgress}
              onLoadedMetadata={handleProgress}
            >
              <source
                src={`data:video/mp4;base64,${singleSong.base64String}`}
                type="video/mp4"
              />
              Your browser does not support the video tag.
            </video>
            { isHovered &&
 <div className="absolute  bottom-0 py-2 px-[20px] w-[100%] bg-[#00000054]">
 <div className="flex justify-between items-center ">
   <input
     type="range"
     min="0"
     max="1"
     step="0.01"
     value={volume}
     onChange={handleVolumeChange}
     className=" w-[70px]"
   />
   <button onClick={togglePlayPause}>
     {isPlaying ? (
       <IoPauseCircleOutline className="cursor-pointer font-[400] text-[50px] text-[#fff] mx-auto z-[999] " />
     ) : (
       <IoPlayCircleOutline className="cursor-pointer font-[400]  text-[50px] text-[#fff] mx-auto z-[999] " />
     )}
   </button>
   <div className="music_wave">
     <div className={`wave ${isPlaying ? "animate" : ""}`} />
     <div className={`wave ${isPlaying ? "animate" : ""}`} />
     <div className={`wave ${isPlaying ? "animate" : ""}`} />
     <div className={`wave ${isPlaying ? "animate" : ""}`} />
     <div className={`wave ${isPlaying ? "animate" : ""}`} />
     <div className={`wave ${isPlaying ? "animate" : ""}`} />
     <div className={`wave ${isPlaying ? "animate" : ""}`} />
     <div className={`wave ${isPlaying ? "animate" : ""}`} />
     <div className={`wave ${isPlaying ? "animate" : ""}`} />
     <div className={`wave ${isPlaying ? "animate" : ""}`} />
     <div className={`wave ${isPlaying ? "animate" : ""}`} />
     <div className={`wave ${isPlaying ? "animate" : ""}`} />
   </div>
   {/* <div className="p-[50px]"> */}

   {/* </div> */}

   {/* <div className="w-[100%]"> */}
   {/* <dotlottie-player
     src="https://lottie.host/4f42a396-bf48-4a48-aeca-78e060f243ae/EmgmQSUKOC.json"
     background="transparent"
     speed={1}
     style={{ width: "100%", display: "inline-block", height: 50 }}
     
   />
   </div> */}

   {/* <iframe  src="https://lottie.host/embed/4f42a396-bf48-4a48-aeca-78e060f243ae/EmgmQSUKOC.json"></iframe> */}
 </div>

 {/* <div className="flex justify-center border-[2px] border-red-300 "> */}
 <div
   onClick={handleSeek}
   className="bg-[#fffefe85] mt-2 overflow-hidden rounded-[10px]"
 >
   <div
     style={{
       width: `${progress}%`,
       background: "#fff",
       height: "5px",
     }}
   ></div>
   {/* </div> */}
 </div>
</div>
            }
           
          </div>
          <div className="mt-[10px]">
            <p className="text-[22px] font-[600] capitalize text-[#000]">
              {singleSong?.songDetails?.songName} |{" "}
              {singleSong?.songDetails?.songTitle}
            </p>
            <p className="text-[18px] font-[600] capitalize text-[#000000c5]">
              Singer name: {singleSong?.songDetails?.singerName}
            </p>
            <p className="text-[14px] font-[600] capitalize text-[#000000c5]">
              Category name: {singleSong?.songDetails?.category}
            </p>
          </div>
          <div className="mt-[10px] py-[30px] px-[20px] rounded-[20px] bg-[#00000028]">
            <p className="text-[16px] font-[400] text-[#000]">
              {singleSong?.songDetails?.songDescription}
            </p>
          </div>
        </>
      )}
    </Drawer>
  );
};

export default Index;
