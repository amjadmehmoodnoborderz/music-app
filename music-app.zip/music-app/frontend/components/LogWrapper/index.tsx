import React from 'react'
import { setSideBar } from "@/store/sideBarSlice";
import { useAppDispatch, useAppSelector } from '@/hooks/redux';
import { FiAlignLeft } from 'react-icons/fi';

const index = () => {
    const {isSideOpened} = useAppSelector(state => state.SideBarReducer);

    const dispatch = useAppDispatch();

    const toggleSideBar = () => {
        dispatch(setSideBar(!isSideOpened));
      };
  return (
    <div className="flex h-[60px]  items-center gap-1 px-[5px]">
    <div onClick={toggleSideBar} className="cursor-pointer flex items-center justify-center hover:bg-[rgba(255,255,255,.1)] h-[40px] min-w-[40px] rounded-full  ">
      <FiAlignLeft className="text-[#fff] text-[25px] " />
    </div>
    <img
      src="/assets/images/logo.png"
      className="h-[50px] w-[150px] object-cover"
      alt=""
    />
  </div>
  )
}

export default index