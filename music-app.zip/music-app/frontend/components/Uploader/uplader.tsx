import React, { memo, useState } from "react";
import { UploadOutlined } from "@ant-design/icons";
import { Button, Upload } from "antd";
import ImgCrop from "antd-img-crop";
import type { GetProp, UploadFile, UploadProps } from "antd";

interface CustomFileUploaderProps {
  accept: string;
  onFilesSelect: (files: File[]) => void;
}

const Uploader: React.FC = ({ musicData, setMusicData }: any) => {
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (event.target.id === "file-upload") {
        setMusicData({ ...musicData, file });
      } else if (event.target.id === "image-upload") {
        setMusicData({ ...musicData, thumbnail: file });
      }
      
      const reader = new FileReader();
      reader.onloadstart = () => {
        console.log("Upload started for", file.name);
      };
      reader.onload = () => {
        console.log("Upload completed for", file.name);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileDelete = () => {
    setMusicData({ ...musicData, file: null });
  };

  const renderFilePreview = () => {
    if (!musicData.file) return null;
    const { type } = musicData.file;
    return (
      <div className="flex flex-col gap-2 mt-[10px]">
        <div className="relative h-[10rem] border-[5px] border-[#0000001f]">
          {type.split("/")[0] === "image" && (
            <img
              src={URL.createObjectURL(musicData.file)}
              className="object-cover h-[100%] w-[100%]"
              alt="Preview"
            />
          )}
          {type.split("/")[0] === "audio" && (
            <audio
              className="block w-[100%]"
              controls
              src={URL.createObjectURL(musicData.file)}
            />
          )}
          {type.split("/")[0] === "video" && (
            <video
              controls
              src={URL.createObjectURL(musicData.file)}
              className="object-cover h-[100%] w-[100%]"
            />
          )}
          <button onClick={handleFileDelete} className="absolute top-0 right-0">
            Del
          </button>
        </div>
      </div>
    );
  };
  const renderThumbnailPreview = () => {
    if (!musicData.thumbnail) return null;
    return (
      <div className="relative mt-[10px] h-[10rem] border-[5px] border-[#0000001f]">
        <img
          src={URL.createObjectURL(musicData.thumbnail)}
          className="object-cover h-[100%] w-[100%]"
          alt="Thumbnail Preview"
        />
      </div>
    );
  };
  return (
    <>
      <label
        htmlFor="file-upload"
        className="block text-center cursor-pointer py-[10px] text-[#fff] px-[10px] rounded-sm bg-[#526fec] w-[100%] custom-file-upload"
      >
        Upload video/audio
        <input
          id="file-upload"
          type="file"
          accept=".mp4, .mp3"
          onChange={handleFileSelect}
          style={{ display: "none" }}
        />
      </label>
      {musicData.file && <div>{renderFilePreview()}</div>}

      <label
        htmlFor="image-upload"
        className="block mt-[30px] text-center cursor-pointer py-[10px] text-[#fff] px-[10px] rounded-sm bg-[#526fec] w-[100%] custom-file-upload"
      >
        Upload thumbnail
        <input
          id="image-upload"
          type="file"
          accept=".jpg, .png, .jpeg"
          onChange={handleFileSelect}
          style={{ display: "none" }}
        />
      </label>

      {musicData?.thumbnail && <div>{renderThumbnailPreview()}</div>}
    </>
  );
};

export default memo(Uploader);
