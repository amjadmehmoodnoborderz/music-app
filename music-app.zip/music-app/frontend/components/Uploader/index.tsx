import React, { useState } from "react";
import {
  Button,
  Col,
  DatePicker,
  Drawer,
  Form,
  Input,
  Row,
  Select,
  Space,
  message,
} from "antd";
import { useAppDispatch, useAppSelector } from "@/hooks/redux";
import { setIsUploaderOpened } from "@/store/uploaderOpenerSlice";
import Uploader from "./uplader";
import globalRequestSender from "@/services/globalRequestSender";
// import { Option } from 'antd/es/mentions';
const { Option } = Select;

const index = () => {
  const { authDetails } = useAppSelector((state) => state.AuthReducer);
 
  console.log(" authDetails",authDetails)

  const { isUploaderOpened } = useAppSelector(
    (state: any) => state.UploaderReducer
  );
  const [messageApi, contextHolder] = message.useMessage();

  const [isLoading, setIsLoading] = useState(false);
  const [musicData, setMusicData] = useState({
    file: "",
    singerName: "",
    songName: "",
    songTitle: "",
    songDescription: "",
    thumbnail: "",
    category:""
  });

  const handleClearForm=()=>{
    setMusicData({
      file: "",
      singerName: "",
      songName: "",
      songTitle: "",
      songDescription: "",
      thumbnail: "",
      category:""
    })
  }

  const handleSubmit = async () => {
    setIsLoading(true);
    try {
      const formData = new FormData();
      const thumbnailFormData = new FormData();

      formData.append("file", musicData.file);
      thumbnailFormData.append("thumbnail", musicData.thumbnail);
      formData.append("songDescription", musicData.songDescription);
      formData.append("songTitle", musicData.songTitle);
      formData.append("songName", musicData.songName);
      formData.append("singerName", musicData.singerName);
      formData.append("category", musicData.category);

      const thubmnailRes:any = await globalRequestSender(
        "POST",
        `thumbnail/create-thumbnail`,
        thumbnailFormData
      );

      console.log("thubmnailRes", thubmnailRes);

      if (thubmnailRes && thubmnailRes?.success) {
        formData.append("thumbnailId", thubmnailRes?.id);
        formData.append("createrId",authDetails?._id)
        const res = await globalRequestSender(
          "POST",
          `music/upload-music`,
          formData
        );

        if (res && res?.success) {
          setIsLoading(false);
          messageApi.open({
            type: "success",
            content: "Your music added",
          });
          handleClearForm()
        }
      } else {
        setIsLoading(false);
        messageApi.open({
          type: "error",
          content: "Something went wronge while adding music",
        });
      }
    } catch (err) {
      console.log(err);
      setIsLoading(false);
    }
  };
  const dispatch = useAppDispatch();
  const onClose = () => {
    dispatch(setIsUploaderOpened(false));
  };
  return (
    <Drawer
      title="Please enter your song's details"
      width={900}
      onClose={onClose}
      open={isUploaderOpened}
      styles={{
        body: {
          paddingBottom: 80,
        },
      }}
      extra={
        <Space>
          <Button onClick={onClose}>Cancel</Button>
          <Button
            onClick={handleSubmit}
            disabled={isLoading}
            loading={isLoading}
            type="primary"
            ghost
          >
            {isLoading ? "Loading" : "Submit"}
          </Button>
        </Space>
      }
    >
      <Form layout="vertical" hideRequiredMark>
        <Row gutter={16}>
          <Col span={12}>
            <Form.Item
              label="Singer name"
              rules={[{ required: true, message: "Please enter singer name" }]}
            >
              <Input
                placeholder="Please enter singer name"
                value={musicData.singerName}
                name="singerName"
                onChange={(e) =>
                  setMusicData({ ...musicData, singerName: e.target.value })
                }
              />
            </Form.Item>
         
      
      <Form.Item
        label="Select category"
        rules={[{ required: true, message: "Please select category" }]}
      >
            {/* <Space wrap> */}
    <Select
      defaultValue="Soothing"
      className="w-[100%]"
      onChange={(value) =>
        setMusicData({ ...musicData, category:value })
      }
      // style={{ width: 120 }}
      // onChange={handleChange}
      options={[
        { value: 'Classic-song', label: 'Classic song' },
        { value: 'Relaxing', label: 'Relaxing' },
        { value: 'Soothing', label: 'Soothing' },
        { value: 'Indian-songs', label: 'Indian songs' },
      ]}
    />
    {/* </Space> */}
            </Form.Item>
      
            <Form.Item
              label="Song title"
              rules={[{ required: true, message: "Please enter song title" }]}
            >
              <Input
                placeholder="Please enter song title"
                value={musicData.songTitle}
                name="songTitle"
                onChange={(e) =>
                  setMusicData({ ...musicData, songTitle: e.target.value })
                }
              />
            </Form.Item>
            <Form.Item
              label="Song name"
              rules={[{ required: true, message: "Please enter song name" }]}
            >
              <Input
                value={musicData.songName}
                name="songName"
                onChange={(e) =>
                  setMusicData({ ...musicData, songName: e.target.value })
                }
                placeholder="Please enter song name"
              />
            </Form.Item>
            <Form.Item
              name="description"
              label="Enter song description "
              rules={[
                {
                  required: true,
                  message: "please enter song description",
                },
              ]}
            >
              <Input.TextArea
                rows={4}
                placeholder="please write here ..."
                value={musicData.songDescription}
                name="songDescription"
                onChange={(e) =>
                  setMusicData({
                    ...musicData,
                    songDescription: e.target.value,
                  })
                }
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <div className="mt-[30px]">
              <Uploader musicData={musicData} setMusicData={setMusicData} />
            </div>

            {/* <Form.Item
              name="url"
              label="Url"
              rules={[{ required: true, message: "Please enter url" }]}
            >
              <Input
                style={{ width: "100%" }}
                addonBefore="http://"
                addonAfter=".com"
                placeholder="Please enter url"
              />
            </Form.Item> */}
          </Col>
        </Row>
        {/* <Row gutter={16}>
          <Col span={12}>
            <Form.Item
              name="owner"
              label="Owner"
              rules={[{ required: true, message: "Please select an owner" }]}
            >
              <Select placeholder="Please select an owner">
              <Option value="xiao">Xiaoxiao Fu</Option>
              <Option value="mao">Maomao Zhou</Option>
            </Select>
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name="type"
              label="Type"
              rules={[{ required: true, message: "Please choose the type" }]}
            >
              <Select placeholder="Please choose the type">
              <Option value="private">Private</Option>
              <Option value="public">Public</Option>
            </Select>
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={16}>
          <Col span={12}>
            <Form.Item
              name="approver"
              label="Approver"
              rules={[
                { required: true, message: "Please choose the approver" },
              ]}
            >
              <Select placeholder="Please choose the approver">
              <Option value="jack">Jack Ma</Option>
              <Option value="tom">Tom Liu</Option>
            </Select>
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name="dateTime"
              label="DateTime"
              rules={[
                { required: true, message: "Please choose the dateTime" },
              ]}
            >
              <DatePicker.RangePicker
                style={{ width: "100%" }}
                getPopupContainer={(trigger) => trigger.parentElement!}
              />
            </Form.Item>
          </Col>
        </Row> */}
        {/* <Row gutter={16}>
          <Col span={24}>
            <Form.Item
              name="description"
              label="Enter song description "
              rules={[
                {
                  required: true,
                  message: "please enter song description",
                },
              ]}
            >
              <Input.TextArea
                rows={4}
                placeholder="please write here ..."
                value={musicData.songDescription}
                name="songDescription"
                onChange={(e) =>
                  setMusicData({
                    ...musicData,
                    songDescription: e.target.value,
                  })
                }
              />
            </Form.Item>
          </Col>
        </Row> */}
      </Form>
    </Drawer>
  );
};

export default index;
