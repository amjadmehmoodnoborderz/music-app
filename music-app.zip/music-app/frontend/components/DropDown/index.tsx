import React from "react";
import type { MenuProps } from "antd";
import { Button, Dropdown, Space } from "antd";
import { useAppDispatch, useAppSelector } from "@/hooks/redux";
import generateRandomColor from "@/helper/generateRandomColor";
import Link from "next/link";
import { setAuthDetails } from "@/store/authSlice";

const DropDown: React.FC = () => {
  const { authDetails } = useAppSelector((state) => state.AuthReducer);
  console.log("authDetails", authDetails);
const dispatch=useAppDispatch()
  const handleLogout=()=>{
    dispatch(setAuthDetails(null))
    localStorage.removeItem("user")
  }
  const items: MenuProps["items"] = [
    {
      key: "1",
      label: (
        <>
          {" "}
          {authDetails ? <span onClick={handleLogout}>Logout</span> : <Link href="/auth">login</Link>}
        </>
      ),
    },
    // {
    //   key: '2',
    //   label: (
    //     <a target="_blank" rel="noopener noreferrer" href="https://www.aliyun.com">
    //       2nd menu item
    //     </a>
    //   ),
    // },
  ];
  return (
    <Space direction="vertical" className=" flex justify-center items-center  w-[30px] h-[30px] rounded-full  overflow-hidden">
      <Dropdown trigger={["click"]} menu={{ items }} placement="bottomRight">
        <Button className="uppercase bg-[#00887A] text-[#fff]">
          {authDetails && authDetails.username ? (
            authDetails.username.at(0)
          ) : (
            <img
              src="/assets/images/avatar.png"
              className="w-[100%] h-[100%] object-contain"
            />
          )}
        </Button>
      </Dropdown>
    </Space>
  );
};

export default DropDown;
