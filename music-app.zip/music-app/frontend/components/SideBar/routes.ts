import { FaHome } from "react-icons/fa";
import { ReactNode } from "react";
import { MdOutlineExplore, MdOutlineLibraryMusic } from "react-icons/md";
import { GiLoveSong } from "react-icons/gi";
import { IoBookmarksOutline } from "react-icons/io5";

interface SidebarRoute {
  link: string;
  name: string;
  icon?: any;
//   child?: {
//     header: string;
//     items: { link: string; name: string; icon: any }[];
//   }[];
}

const sideBarRoutes: SidebarRoute[] = [
  {
    link: "/",
    name: "Home",
    icon: FaHome,
 
  },
  {
    link: "/explore",
    name: "Explore",
    icon: MdOutlineExplore,
  },
  {
    link: "/library",
    name: "Library",
    icon: MdOutlineLibraryMusic,
  },
];


const accordion =[
        {
          header: "My Stuff",
          items: [
            { link: "/my-songs", name: "My songs", icon: GiLoveSong },
            { link: "/my-favourite", name: "My Favourite", icon: IoBookmarksOutline },
          ],
        },
      
]
export { sideBarRoutes,accordion };
