import React, { useRef, useState } from "react";
import { sideBarRoutes, accordion } from "./routes";
import Link from "next/link";
import { useAppDispatch, useAppSelector } from "@/hooks/redux";
import LogWrapper from "../LogWrapper";
import { Button, Collapse, Divider, Modal } from "antd";
import { setIsUploaderOpened } from "@/store/uploaderOpenerSlice";
import { PlusOutlined } from "@ant-design/icons";
import { useRouter } from "next/router";
import { IoIosArrowDown, IoIosArrowUp } from "react-icons/io";

const index = ({ setIsAuthenticated }:any) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const accordRef = useRef();
  const [accordionOpen, setAccordionOpen] = useState(false);
  const { isSideOpened } = useAppSelector((state) => state.SideBarReducer);
  const { IsUploaderOpened } = useAppSelector(
    (state: any) => state.UploaderReducer
  );
  const dispatch = useAppDispatch();
  const showDrawer = () => {
    const user = localStorage.getItem("user");
    if (user) {
      dispatch(setIsUploaderOpened(true));
    } else {
      setIsAuthenticated(false);
    }
  };

  return (
    <>
      <aside
        className={`grow-0 fixed    ${
          isSideOpened ? "w-[250px] bg-[#000]" : "w-[200px] bg-transparant"
        }  top-0 bottom-0 translate-x-[-100%] lg:translate-x-[0%] border-r-[1px] border-[#a09e9e3d] `}
      >
        <div className="mt-[20px] w-[200px] px-[20px] ">
          <LogWrapper />
        </div>

        <ul
          className={`px-[10px] mt-[30px] ${!isSideOpened ? "w-[80px]" : ""} `}
        >
          {sideBarRoutes.map((route, index) => (
            <li
              key={index}
              className="text-[#fff] hover:bg-[rgba(255,255,255,.1)] rounded-md py-[10px] items-center flex mb-[10px]"
            >
              {route.link ? (
                <Link
                  href={route.link}
                  className={`flex w-[100%] ${
                    !isSideOpened
                      ? "flex-col items-center gap-1 text-[12px] "
                      : "items-center gap-4 pl-[20px]"
                  }`}
                >
                  {route.icon && (
                    <route.icon
                      className={!isSideOpened ? "text-[18px]" : "text-[30px]"}
                    />
                  )}
                  {route.name}
                </Link>
              ) : (
                <div
                  className={`flex w-[100%] ${
                    !isSideOpened
                      ? "flex-col items-center gap-1 text-[12px] "
                      : "items-center gap-4 pl-[20px]"
                  }`}
                >
                  {route.icon && (
                    <route.icon
                      className={!isSideOpened ? "text-[18px]" : "text-[30px]"}
                    />
                  )}
                  {route.name}
                </div>
              )}
            </li>
          ))}
        </ul>

        <ul className={`px-[10px]   mt-[30px]`}>
          {accordion.map((route, index) => (
            <li
              onClick={() => setAccordionOpen((prev) => !prev)}
              key={index}
              className="text-[#fff] px-[10px] bg-[rgba(255,255,255,.1)] hover:bg-[rgba(255,255,255,.1)] rounded-md  w-[100%] items-center justify-between flex flex-col  mb-[10px]"
            >
              <button className=" flex justify-between items-center w-[100%] py-[10px]  ">
                {route.header}{" "}
                {accordionOpen ? <IoIosArrowDown /> : <IoIosArrowUp />}
              </button>
              {accordionOpen &&
                route.items.map((item, itemIndex) => (
                  <div
                    key={itemIndex}
                    className="flex flex-col py-[10px] w-[100%]"
                  >
                    <Link
                      href={item.link}
                      className={`flex w-[100%] ${
                        !isSideOpened
                          ? "flex-col items-center gap-1 text-[12px] "
                          : "items-center gap-4 pl-[20px]"
                      }`}
                    >
                      {item.icon && (
                        <item.icon
                          className={
                            !isSideOpened ? "text-[18px]" : "text-[30px]"
                          }
                        />
                      )}
                      {item.name}
                    </Link>
                
                  </div>
                ))}
            </li>
          ))}
        </ul>

        <div className="w-[90%] mx-auto my-[20px] h-[1px] bg-[rgba(255,255,255,0.11)]"></div>
        <Button
          type="primary"
          onClick={showDrawer}
          className="w-[90%] ml-[10px] block mx-auto"
          icon={<PlusOutlined />}
        >
          Add music
        </Button>

    
      </aside>
    </>
  );
};

export default index;
