import { useAppDispatch } from "@/hooks/redux";
import globalRequestSender from "@/services/globalRequestSender";
import { setAudios, setVidoes } from "@/store/musicSlice";
import { Button } from "antd";
import React, { useState } from "react";

const categories = ["All","Soothing", "Classic song", "Relaxing", "Indian songs"];



const index = () => {
  const dispatch=useAppDispatch()
  const [selectedCategory, setSelectedCategory]= useState("All")
// Define the handleMusicByCategory function
const handleMusicByCategory = async(category: string) => {
  if (category === "All") {
    window.location.reload();
    return
}
  try {
    const response = await globalRequestSender(
      "GET",
      `music/get-music-by-category/${category}`,
    );
    console.log("response.songs", response.songs)
    if(response && response?.songs &&response?.songs)
    {
   
        const vidoeSongs = response.songs.filter((song: any) => {
          return song.metadata.fileType === "video";
        });
        dispatch(setVidoes(vidoeSongs));
        const audioSongs = response.songs.filter((song: any) => {
          return song.metadata.fileType === "audio";
        });
        console.log("vidoeSongs, audioSongs",vidoeSongs,audioSongs)

        dispatch(setAudios(audioSongs));

      

    }

  } catch (error) {
    
  }finally{

  }
  // Do something with the category, for example, call an API to fetch music files by category
  console.log("category", category);
};
  return (
    <div className="flex gap-2 pb-2 overflow-x-auto mb-[50px]">
      {categories.map((category, index) => {
        const words = category.split(" ");
        const categoryValue =
          words.length > 1 ? `${words[0]}-${words[1]}` : words[0];

        return (
          <Button
            key={index}
            type={`${selectedCategory===category?"primary":"default"}`}
            onClick={() => {setSelectedCategory(category)
              handleMusicByCategory(categoryValue)}}
          >
            {category}
          </Button>
        );
      })}
    </div>
  );
};

export default index;
