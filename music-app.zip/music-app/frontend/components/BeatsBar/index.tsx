import React, { useState, useEffect, useRef } from 'react';

const BeatsBar = ({ audioFiles }) => {
  const canvasRefs = useRef([]);
  const audioElements = useRef([]);

  useEffect(() => {
    canvasRefs.current = audioFiles.map(() => React.createRef());
    audioElements.current = audioFiles.map(() => new Audio());
  }, [audioFiles]);

  useEffect(() => {
    audioFiles.forEach((audioFile, index) => {
      audioElements.current[index].src = `data:audio/mp3;base64,${audioFile}`;
      audioElements.current[index].play();
    });
  }, [audioFiles]);

  useEffect(() => {
    const audioContexts = audioElements.current.map(() => new (window.AudioContext || window.webkitAudioContext)());
    const analyzers = audioContexts.map((ctx) => ctx.createAnalyser());

    analyzers.forEach((analyzer, index) => {
      const source = audioContexts[index].createMediaElementSource(audioElements.current[index]);
      source.connect(analyzer);
      analyzer.connect(audioContexts[index].destination);
      analyzer.fftSize = 256;
    });

    const renderFrames = () => {
      requestAnimationFrame(renderFrames);

      analyzers.forEach((analyzer, index) => {
        const canvas = canvasRefs.current[index]?.current;
        if (!canvas) {
          console.error(`Canvas at index ${index} is null`);
          return;
        }
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          console.error(`Failed to get 2D context for canvas at index ${index}`);
          return;
        }
        
        const bufferLength = analyzer.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        analyzer.getByteFrequencyData(dataArray);

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        const barWidth = (canvas.width / bufferLength) * 2.5;
        let x = 0;

        for (let i = 0; i < bufferLength; i++) {
          const barHeight = dataArray[i] / 2;
          ctx.fillStyle = `rgb(${barHeight + 100},50,50)`;
          ctx.fillRect(x, canvas.height - barHeight / 2, barWidth, barHeight);
          x += barWidth + 1;
        }
      });
    };

    renderFrames();

    return () => {
      cancelAnimationFrame(renderFrames);
      audioContexts.forEach((ctx) => ctx.close());
    };
  }, [audioFiles]);

  return (
    <div>
      {audioFiles.map((_, index) => (
        <div key={index}>
          <canvas ref={canvasRefs.current[index]} />
          {/* You can provide additional controls or information here if needed */}
        </div>
      ))}
    </div>
  );
};

export default BeatsBar;
