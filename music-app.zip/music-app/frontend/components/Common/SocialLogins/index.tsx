import { useUser } from '@auth0/nextjs-auth0/client';
import React from 'react'

const index = () => {
    const { user, error, isLoading } = useUser();

    console.log("user ====", user)
  return (
    <div className="">
    <button disabled={isLoading}  className="bg-transparant border-[1px] rounded-[8px] border-[rgba(255,255,255,0.15)] mt-[20px] cursor-pointer text-[#e2e0e0a2] w-[100%] ">
      <a href="/api/auth/login" className='w-[100%] block py-[10px]'>
      Go with google
      </a>
     
    </button>
    <button disabled={isLoading}  className="bg-transparant border-[1px] rounded-[8px] border-[rgba(255,255,255,0.15)] mt-[20px] cursor-pointer text-[#e2e0e0a2] w-[100%] py-[10px]">
      Go with facebook
    </button>
  </div>
  )
}

export default index