import React from "react";
import DropDown from "../DropDown";
import { useAppDispatch, useAppSelector } from "@/hooks/redux";
import { CiSearch } from "react-icons/ci";
import { setSideBar } from "@/store/sideBarSlice";
import { FiAlignLeft } from "react-icons/fi";
interface NavBarProps {
  scrolled: boolean;
}
const index: React.FC<NavBarProps> = ({ scrolled }) => {
  const { isSideOpened } = useAppSelector((state) => state.SideBarReducer);
console.log("isSideOpened",isSideOpened,scrolled)


const dispatch = useAppDispatch();

const toggleSideBar = () => {
    dispatch(setSideBar(!isSideOpened));
  };
  return (
    <nav
      className={`fixed  ${
        scrolled && isSideOpened ? "bg-black border-b-[1px] border-[#a09e9e3d]" : ""
      }  ${
        isSideOpened ? "left-[0px] lg:left-[250px] right-0" :"sm:left-[0px] right-0 lg:left-[150px]"
      }  top-0 left-0 z-50 gap-6  lg:pl-[80px] px-[20px] py-[10px]  flex items-center`}
    >
        <div onClick={toggleSideBar} className=" sm:flex lg:hidden  border-red-600 border-[1px] cursor-pointer items-center justify-center hover:bg-[rgba(255,255,255,.1)] h-[40px] min-w-[40px] rounded-full  ">
      <FiAlignLeft className="text-[#fff] text-[25px] " />
    </div>
      {/* {!isSideOpened && <LogWrapper />} */}
      <div className="h-[40px] relative  flex-grow overflow-hidden rounded-[8px] w-[200px] lg:max-w-[500px]">
        <CiSearch className="absolute text-[#e2e0e0a2]  text-[20px] top-[50%] left-[20px] translate transform translate-x-[-50%] translate-y-[-50%] " />
        <input
          type="text"
          className="h-[100%] pl-[40px] border-[1px] rounded-[8px] border-[rgba(255,255,255,0.15)] text-[16px] text-[#fff] font-[500] placeholder-[#e2e0e0a2] placeholder-opacity-100  bg-[rgba(255,255,255,.15)] outline-none overflow-hidden w-[100%] px-[20px]"
          placeholder="Search songs, albums,artist, podcasts"
        />
      </div>

      <div className="auth-side ml-auto justify-self-end flex justify-end ">
        <DropDown />
      </div>
    </nav>
  );
};

export default index;
