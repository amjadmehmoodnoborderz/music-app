import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface music {
 audioSongs:any[],
 videoSongs:any[]
}






const musicSlice = createSlice({
  name: "music",
  initialState:{
    audioSongs:[],
    videoSongs:[]
  },
  reducers: {
    setVidoes: (state, action: PayloadAction<music | []>) => {
      state.videoSongs = action.payload;
    },
    setAudios: (state, action: PayloadAction<music | []>) => {
        state.audioSongs = action.payload;
      },
  },
});

export const { setVidoes ,setAudios} = musicSlice.actions;
export default musicSlice.reducer;
