import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface AuthDetails {
  username?:string,
  email?:string,
  name?:string,
  pictture?:string
}

const loadAuthDetailsFromLocalStorage = (): AuthDetails | null => {
    if (typeof window !== 'undefined') {
      const storedAuthDetails = window.localStorage.getItem("user");
      if (storedAuthDetails) {
        return JSON.parse(storedAuthDetails);
      }
    }
    return null;
  };

interface AuthState {
    authDetails: AuthDetails | null; 
  }
const initialState: AuthState = {
    authDetails: loadAuthDetailsFromLocalStorage(),
  };

const authSlice = createSlice({
  name: "sideBar",
  initialState,
  reducers: {
    setAuthDetails: (state, action: PayloadAction<AuthDetails | null>) => {
      state.authDetails = action.payload;
    },
  },
});

export const { setAuthDetails } = authSlice.actions;
export default authSlice.reducer;
