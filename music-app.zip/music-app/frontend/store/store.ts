import { configureStore } from "@reduxjs/toolkit";

import SideBarReducer from "./sideBarSlice";
import AuthReducer from "./authSlice";
import UploaderReducer from "./uploaderOpenerSlice";
import musicReducer from "./musicSlice";


export const store = configureStore({
  reducer: { SideBarReducer, UploaderReducer, AuthReducer,musicReducer },
});

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;

// Can still subscribe to the store
