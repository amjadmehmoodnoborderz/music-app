import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface Uplader {
  isUploaderOpened: boolean;
}
const uploaderSlice = createSlice({
  name: "isUploaderOpened",
  initialState: {
    isUploaderOpened: false,
    songPlayer:false,
  },
  reducers: {
    setIsUploaderOpened: (state, action: PayloadAction<boolean>) => {
      state.isUploaderOpened = action.payload;
    },
    setSongPlayer: (state, action: PayloadAction<boolean>) => {
      state.songPlayer = action.payload;
    },
  },
});

export const { setIsUploaderOpened,setSongPlayer } = uploaderSlice.actions;
export default uploaderSlice.reducer;
