import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { RootState } from "./store";

export interface SideBar {
  isSideOpened: boolean;
}
const sideBarSlice = createSlice({
  name: "sideBar",
  initialState: {
    isSideOpened: true,
  },
  reducers: {
    setSideBar: (state, action: PayloadAction<boolean>) => {
      state.isSideOpened = action.payload;
    },
  },
});

export const { setSideBar } = sideBarSlice.actions;
export default sideBarSlice.reducer;
