// hooks/checkoutLoggedIn.ts
import { useRouter } from "next/router";
import { useEffect } from "react";
import { useAppSelector } from "./redux";

const checkoutLoggedIn = () => {
  const router = useRouter();
  const {authDetails} = useAppSelector((state) => state.AuthReducer);
  useEffect(() => {
    // Check if the user is logged in
    const isLoggedIn = authDetails; // Implement this function
    // If the user is logged in, redirect away from authentication pages
    if (isLoggedIn) {
      // If the user accidentally accesses an authentication page, redirect them to the previous route
      if (router.pathname.startsWith("/auth")) {
        // Capture the current route before redirecting to the authentication page
        const destination = encodeURIComponent(router.asPath);
        router.push(`/`);
      }
    }
  }, []);

  return null; // This hook doesn't render anything, it just performs the redirect
};

export  {checkoutLoggedIn};






