import jwt from "jsonwebtoken";

export const generateJWT = async (userId) => {
  try {
    const token = await jwt.sign({ userId  },process.env.JWT_SECRET_KEY,{expiresIn: "1hr"});

    console.log("toekn", token);

    return token;
  } catch (error) {
    console.log("error while generating token");
  }
};
