import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { connectToDatabase } from "./db.js";
import authRoute from "./routes/userRoute.js";
import musicRoute from "./routes/musicRoute.js";
import thubmnailRoute from "./routes/thumbnailRoute.js"

const app = express();
dotenv.config();

const PORT = process.env.PORT || 5000;
connectToDatabase();




app.use(cors());
app.use(express.json());
app.use("/api/v1/auth", authRoute);
app.use("/api/v1/music", musicRoute);
app.use("/api/v1/thumbnail", thubmnailRoute);


app.listen(PORT, () => {
  console.log(` server is running at port ${PORT}`);
});
