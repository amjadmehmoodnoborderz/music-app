// FileModel.js
import mongoose from "mongoose";
const ThumbnailSchema = new mongoose.Schema({
  thumbnail: String,

});

const ThumbnailModal = mongoose.model("Thumbnail", ThumbnailSchema);

export default ThumbnailModal;
