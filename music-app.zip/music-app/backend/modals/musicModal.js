// FileModel.js
import mongoose from "mongoose";

const MusicSchema = new mongoose.Schema({
  songName: String,
  category: {
    type:String,
    required:true
  },
  songId: String,
  songTitle:String,
  songDescription:String,
  singerName:String,
  createrId:String,
  thumbnail: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Thumbnail" // This should match the name of your thumbnail model
  }
});

const MusicModal = mongoose.model("Music", MusicSchema);

export default MusicModal;
