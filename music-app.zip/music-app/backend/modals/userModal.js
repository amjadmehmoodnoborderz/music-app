import mongoose from "mongoose";
import isEmail from "validator/lib/isEmail.js";

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    validate: {
      validator: (email) => isEmail(email),
      message: "Invalid email format",
    },
  },
  username: {
    type: String,
    required: true,
    validate: [
      {
        validator: (username) => !/\s/.test(username),
        message: "Username cannot contain spaces",
      },
      {
        validator: (username) => username.length <= 15,
        message: "Username should not exceed 15 characters",
      },
    ],
  },

  favouriteSongs:[],
  password: {
    type: String,
    required: true,
 
  },
});



const userModel = mongoose.model("User", userSchema);

export { userModel };
