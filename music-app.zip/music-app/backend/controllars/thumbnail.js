import ThumbnailModal from "../modals/thumbnailModal.js";

const createThubmnail = async (req, res) => {
    try {
  
      
    //   const { singerName, songTitle, songName, songDescription } = req.body;
      const  thumbnail  = req.file; // Access files sent in form data
    //   const { id } = file[0]; // Assuming file is sent as an array
  // console.log("thumbnail",thumbnail)
  // console.log("req.files ===",file)
  
      let thumbnailBase64 = null;
  
      // Check if thumbnail data is available
      if (thumbnail && thumbnail && thumbnail.buffer) {
        // Convert thumbnail buffer to base64
        thumbnailBase64 = thumbnail.buffer.toString("base64");
      }
  
      // Save file to GridFS (already handled by Multer)
      // Save other song details and thumbnail (if available) to regular MongoDB
      const newThumbnail = await ThumbnailModal.create({
        thumbnail: thumbnailBase64,
      });
  console.log("newThumbnail",newThumbnail)
      res.status(201).json({
        success: true,
        error: false,
        id:newThumbnail._id,
        msg: "Thumbnail uploaded successfully !",
      });
    } catch (error) {
      console.error("Error uploading music:", error);
      res.status(400).json({
        success: false,
        error: true,
        msg: "Unable to upload the file !",
      });
    }
  };

  export default createThubmnail