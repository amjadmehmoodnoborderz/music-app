import { Transform } from "stream";
import { bucket } from "../GridFS.js";
import MusicModal from "../modals/musicModal.js";
import mongoose from "mongoose";
import  {ObjectId}  from 'mongodb';

// Import gfs from your db.js file
// const conn = mongoose.createConnection("mongodb://localhost:27017/mern-music-app");
// const gfs = new mongoose.mongo.GridFSBucket(conn.db);

const uploadMusic = async (req, res) => {
  try {
    const {
      singerName,
      thumbnailId,
      createrId,
      songTitle,
      thumbnail,
      songName,
      category,
      songDescription,
    } = req.body;
    const { id } = req.file; // Access files sent in form data
    // console.log("thumbnail",thumbnail)
    // console.log("req.files ===",file)
    // Save file to GridFS (already handled by Multer)
    // Save other song details and thumbnail (if available) to regular MongoDB
    const newSong = await MusicModal.create({
      songId: id,
      singerName,
      songName,
      songTitle,
      createrId,
      category,
      songDescription,
      thumbnail: thumbnailId,
    });

    res.status(201).json({
      success: true,
      error: false,
      msg: "File uploaded successfully !",
    });
  } catch (error) {
    console.error("Error uploading music:", error);
    res.status(400).json({
      success: false,
      error: true,
      msg: "Unable to upload the file !",
    });
  }
};

const getMusicFiles = async (_req, res) => {
  try {
    const filesData = await Promise.all(
      (
        await bucket.find().toArray()
      ).map(async (file) => {
        const fileStream = bucket.openDownloadStream(file._id);
        const chunks = [];

        return new Promise((resolve, _reject) => {
          fileStream
            .on("data", (chunk) => {
              chunks.push(chunk);
            })
            .on("end", async () => {
              const fbuf = Buffer.concat(chunks);
              const fileBase64String = fbuf.toString("base64");

              // Determine file type based on file extension or content type
              let fileType;
              if (file.contentType) {
                // Use content type if available
                fileType = file.contentType.split("/")[0]; // Assumes content type is like 'image/jpeg', 'audio/mp3', 'video/mp4'
              } else {
                // Fallback: Use file extension
                const fileExtension = file.filename
                  .split(".")
                  .pop()
                  .toLowerCase();
                if (
                  ["jpg", "jpeg", "png", "gif", "bmp"].includes(fileExtension)
                ) {
                  fileType = "image";
                } else if (["mp3", "wav", "ogg"].includes(fileExtension)) {
                  fileType = "audio";
                } else if (["mp4", "avi", "mkv"].includes(fileExtension)) {
                  fileType = "video";
                } else {
                  fileType = "unknown";
                }
              }

              const metadata = {
                id: file._id, // Include file ID
                filename: file.filename,
                fileType,
              };

              const songDetails = await MusicModal.findOne({
                songId: file._id,
              }).populate("thumbnail");
              resolve({ metadata, fileBase64String, songDetails });
            })
            .on("error", (error) => {
              console.error(error);
              resolve(null);
            });
        });
      })
    );

    res.status(200).json({ songs: filesData });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: { text: `Internal Server Error`, error },
    });
  }
};

import { Readable } from "stream";
import { promisify } from "util";
import { pipeline } from "stream/promises";

const getSingleMusicFile = async (req, res) => {
  try {
    const { id } = req.params;

    // Check if file exists
    const file = await bucket
      .find({ _id: new mongoose.Types.ObjectId(id) })
      .toArray();
    if (file.length === 0) {
      return res.status(404).json({ error: { text: "File not found" } });
    }

    // create a stream to read from the bucket
    const downloadStream = bucket.openDownloadStream(
      new mongoose.Types.ObjectId(id)
    );

    // Create a readable stream to collect the file data
    const readableStream = new Readable().wrap(downloadStream);

    // Convert the file data to base64
    let base64String = "";
    readableStream.on("data", (chunk) => {
      base64String += chunk.toString("base64");
    });

    // let fileType;
    // if (file.contentType) {
    //   // Use content type if available
    //   fileType = file.contentType.split("/")[0]; // Assumes content type is like 'image/jpeg', 'audio/mp3', 'video/mp4'
    // } else {
    //   // Fallback: Use file extension
    //   const fileExtension = file.filename.split(".").pop().toLowerCase();
    //   if (["jpg", "jpeg", "png", "gif", "bmp"].includes(fileExtension)) {
    //     fileType = "image";
    //   } else if (["mp3", "wav", "ogg"].includes(fileExtension)) {
    //     fileType = "audio";
    //   } else if (["mp4", "avi", "mkv"].includes(fileExtension)) {
    //     fileType = "video";
    //   } else {
    //     fileType = "unknown";
    //   }
    // }

    const songDetails = await MusicModal.findOne({
      songId: id,
    }).populate("thumbnail");
    readableStream.on("end", () => {
      // Send the base64 string in the response
      let fileType = file[0].contentType
        ? file[0].contentType.split("/")[0]
        : "unknown";
      const metadata = {
        id: file._id, // Include file ID
        filename: file.filename,
        fileType,
      };
      res.status(200).json({ metadata, songDetails, base64String });
    });



    // Handle any errors
    readableStream.on("error", (error) => {
      console.error(error);
      res.status(500).json({ error: { text: `Internal Server Error`, error } });
    });
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: { text: `Unable to download file`, error } });
  }
};

const getMusicByCategory = async (req, res) => {
  try {
    const { category } = req.params;

    console.log("category", category);

    // Find music files based on the category from MusicModal
    const songs = await MusicModal.find({ category }).populate("thumbnail");

    if (!songs || songs.length === 0) {
      return res
        .status(404)
        .json({ error: { text: "No songs found for this category" } });
    }

    // Extract song IDs
    const songIds = songs.map((song) => song.songId);

    // Retrieve music files using the IDs from GridFS
    const filesData = await Promise.all(
      (
        await bucket.find().toArray()
      ).map(async (file) => {
        const fileStream = bucket.openDownloadStream(file._id);
        const chunks = [];
        return new Promise((resolve, _reject) => {
          fileStream
            .on("data", (chunk) => {
              chunks.push(chunk);
            })
            .on("end", async () => {
              const fbuf = Buffer.concat(chunks);
              const fileBase64String = fbuf.toString("base64");
              // Determine file type based on file extension or content type
              let fileType;
              if (file.contentType) {
                // Use content type if available
                fileType = file.contentType.split("/")[0]; // Assumes content type is like 'image/jpeg', 'audio/mp3', 'video/mp4'
              } else {
                // Fallback: Use file extension
                const fileExtension = file.filename
                  .split(".")
                  .pop()
                  .toLowerCase();
                if (
                  ["jpg", "jpeg", "png", "gif", "bmp"].includes(fileExtension)
                ) {
                  fileType = "image";
                } else if (["mp3", "wav", "ogg"].includes(fileExtension)) {
                  fileType = "audio";
                } else if (["mp4", "avi", "mkv"].includes(fileExtension)) {
                  fileType = "video";
                } else {
                  fileType = "unknown";
                }
              }

              const metadata = {
                id: file._id, // Include file ID
                filename: file.filename,
                fileType,
              };

              const songDetails = await MusicModal.findOne({
                songId: file._id,
              }).populate("thumbnail");
              resolve({ metadata, fileBase64String, songDetails });
            })
            .on("error", (error) => {
              console.error(error);
              resolve(null);
            });
        });
      })
    );

    // Create a map of song IDs to file data
    const filesMap = filesData.reduce((acc, file) => {
      acc[file.songDetails.songId.toString()] = file;
      return acc;
    }, {});

    // Filter files based on song IDs
    const files = songIds.map((songId) => filesMap[songId.toString()]);

    // console.log("filesData", filesData);

    res.status(200).json({ songs: files });
  } catch (error) {
    console.error("Error getting music by category:", error);
    res.status(500).json({ error: { text: "Internal Server Error" } });
  }
};

const myFavourite = async (req, res) => {
  try {
    const { IDs } = req.params;
    const songIds = `${IDs}`.split(',').map(id => id.trim());
    let filesData = [];

    await Promise.all(songIds.map(async (songId) => {
      const file = await bucket.find({_id: new mongoose.Types.ObjectId(songId)}).toArray();

      if (!file || file.length === 0) {
        console.error(`File with ID ${songId} not found`);
        return; // Skip processing if file not found
      }

      const fileStream = bucket.openDownloadStream(file[0]._id);
      let fileBase64String = '';
      
      fileStream.on("data", (chunk) => {
        fileBase64String += chunk.toString('base64');
      });

      // Wrap file processing in a Promise for async/await
      const fileData = await new Promise((resolve, reject) => {
        fileStream.on("end", async () => {
          // Determine file type based on file extension or content type
          let fileType;
          if (file[0].contentType) {
            fileType = file[0].contentType.split("/")[0];
          } else {
            const fileExtension = file[0].filename.split(".").pop().toLowerCase();
            fileType = (["jpg", "jpeg", "png", "gif", "bmp"].includes(fileExtension)) ? "image" :
                        (["mp3", "wav", "ogg"].includes(fileExtension)) ? "audio" :
                        (["mp4", "avi", "mkv"].includes(fileExtension)) ? "video" :
                        "unknown";
          }

          const metadata = {
            id: file[0]._id,
            filename: file[0].filename,
            fileType,
          };

          const songDetails = await MusicModal.findOne({ songId: file[0]._id }).populate("thumbnail");

          resolve({ metadata, fileBase64String, songDetails });
        });

        fileStream.on("error", (error) => {
          console.error(`Error streaming file with ID ${songId}:`, error);
          reject(error);
        });
      });

      filesData.push(fileData);
    }));

    console.log("filesData", filesData);
    res.status(200).json({ songs: filesData });
  } catch (error) {
    console.error("Error getting music by IDs:", error);
    res.status(500).json({ error: { text: "Internal Server Error" } });
  }
};





export { uploadMusic, getMusicByCategory, myFavourite,getMusicFiles, getSingleMusicFile };
