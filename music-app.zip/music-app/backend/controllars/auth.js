import { generateJWT } from "../jwt.js";
import { userModel } from "../modals/userModal.js";
import bcrypt from "bcrypt";
const createUser = async (req, res) => {
  const { email, username, password } = req.body;

  console.log({ email, username, password });

  try {
    if (!email || !username || !password) {
      return res.status(400).json({
        success: false,
        error: true,
        msg: "Email, username, and password are required!",
      });
    }

    const isUserExist = await userModel.findOne({ email });

    if (isUserExist) {
      return res.status(400).json({
        success: false,
        error: true,
        msg: "This user already exists!",
      });
    } else {
      const salt = await bcrypt.genSalt(10);

      const hashedPass = await bcrypt.hash(password, salt);
      const user = await userModel.create({
        email,
        username,
        password: hashedPass,
      });

      const userCreated = await user.save();

      return res.status(200).json({
        success: true,
        error: false,
        msg: "User created!",
      });
    }
  } catch (error) {
    console.error("Error creating user:", error);
    return res.status(500).json({
      success: false,
      error: true,
      msg: "Something went wrong!",
    });
  }
};

const loginUser = async (req, res) => {
  const { email, password } = req.body;
  try {
    if (!email.trim() || !password.trim()) {
      return res.status(400).json({
        success: false,
        error: true,
        msg: "Email and password are required!",
      });
    }

    const user = await userModel.findOne({ email });
    if (user) {
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (isPasswordValid) {
        const { password, ...rest } = user.toObject();
        const token = await generateJWT(user._id);
        return res.status(200).json({
          success: true,
          error: false,
          user: { ...rest },
          token,
          msg: "you are login successfully!",
        });

      } else {
        return res.status(401).json({
          success: false,
          error: true,
          user: null,
          msg: "Password is incorrect!",
        });
      }
    } else {
      return res.status(401).json({
        success: false,
        error: true,
        user: null,
        msg: "User not found!",
      });
    }
  } catch (error) {
    return res.status(500).json({
      success: false,
      error: false,
      msg: "Something went wronge!",
    });
  }
};

const addFavouriteSong = async (req, res) => {
  const { songId, userId } = req.params;

  try {
    // Validate if both songId and userId are provided
    if (!songId || !userId) {
      return res.status(400).json({
        success: false,
        error: true,
        msg: "Both songId and userId are required!",
      });
    }

    // Find the user by userId
    const user = await userModel.findById(userId);
    if (!user) {
      // If user not found, return appropriate response
      return res.status(404).json({
        success: false,
        error: true,
        msg: "User not found!",
      });
    }

    // Check if the songId already exists in the user's favouriteSongs array
    if (user.favouriteSongs.includes(songId)) {
      // Remove the songId from the favouriteSongs array
      user.favouriteSongs = user.favouriteSongs.filter(id => id !== songId);
      // Return response indicating the song is removed from the favourite list
      await user.save();
      return res.status(200).json({
        success: true,
        error: false,
        msg: "Song removed from favourite list",
      });
    } else {
      // Add the songId to the user's favouriteSongs array
      user.favouriteSongs.push(songId);
      await user.save();
      // Return response indicating the song is added to the favourite list
      return res.status(200).json({
        success: true,
        error: false,
        msg: "Song added to favourite list",
      });
    }
  } catch (error) {
    // If any error occurs, return internal server error
    return res.status(500).json({
      success: false,
      error: true,
      msg: "Something went wrong!",
    });
  }
};



export { createUser, loginUser,addFavouriteSong };
