import multer from "multer";
import { GridFsStorage } from "multer-gridfs-storage";
const mongoURI = "mongodb://localhost:27017/mern-music-app";

const storage = new GridFsStorage({
  url: mongoURI,
  file: (req, file) => {
    return new Promise((resolve, _reject) => {
      const fileInfo = {
        filename: file.originalname,
        bucketName: "filesBucket",
      };
      resolve(fileInfo);
    });
  },
});

const thumbnailStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "thumbnail");
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  },
});
// const cpUpload = upload.fields([{ name: 'file', maxCount: 1 }, { name: 'thumbnail', maxCount: 1 }]);

const uploadFile = multer({ storage }).single("file");
const uploadThumbnail = multer({ storage: thumbnailStorage }).single(
  "thumbnail"
);

export { uploadFile, uploadThumbnail};
