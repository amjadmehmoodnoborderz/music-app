// db.js
import Grid from "gridfs-stream";
import mongoose from "mongoose";

const uri = "mongodb://localhost:27017/mern-music-app"; // Replace with your actual connection URI
console.log("uri ====", uri);
const conn = mongoose.createConnection(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Init gfs
let gfs;

conn.once('open', () => {
  // Initialize stream
  gfs = Grid(conn.db, mongoose.mongo);
  gfs.collection('uploads');
  console.log("GridFS connected to MongoDB");
});

conn.on('error', (error) => {
  console.error("MongoDB connection error:", error);
});

const connectToDatabase = async () => {
  try {
    await mongoose.connect(uri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log("Connected to MongoDB");
  } catch (error) {
    console.error("Error connecting to MongoDB:", error);
  }
};

export { connectToDatabase, gfs };
