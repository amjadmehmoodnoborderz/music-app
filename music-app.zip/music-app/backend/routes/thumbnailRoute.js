import express from "express";
import createThubmnail from "../controllars/thumbnail.js";
import multer from "multer";
const router = express.Router();
const storage = multer.memoryStorage();

const upload = multer({ storage });
router.post("/create-thumbnail", upload.single("thumbnail"), createThubmnail);

export default router;
