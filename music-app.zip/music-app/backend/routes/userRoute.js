import express from "express"
import { addFavouriteSong, createUser,loginUser } from "../controllars/auth.js"
const router= express.Router()


router.post("/create-user", createUser)

router.post("/login-user", loginUser)
router.put("/add-favourite-song/:userId/:songId", addFavouriteSong)




export default router