import bodyParser from "body-parser";
import express from "express";
import multer from "multer";
import { GridFsStorage } from "multer-gridfs-storage";
import methodOverride from "method-override";
import { uploadMusic, getMusicFiles } from "../controllars/music.js";
const router = express.Router();
const app = express();
// Middleware
app.use(bodyParser.json());
app.use(methodOverride("_method"));
// import { uploadThumbnail, uploadFile } from "../middlewares/uploads.js";
// console.log({ uploadThumbnail, uploadFile })
// Mongo URI
const mongoURI = "mongodb://localhost:27017/mern-music-app";

const storage = new GridFsStorage({
  url: mongoURI,
  file: (req, file) => {
    console.log("red ===", req)
    return new Promise((resolve, _reject) => {
      const fileInfo = {
        filename: file.originalname,
        bucketName: "filesBucket",
      };
      resolve(fileInfo);
    });
  },
});
const thumbnailStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    console.log("red ===", req)
    cb(null, 'thumbnails');
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  }
});
const uploadFile = multer({storage});
const uploadThumbnail = multer({ storage:thumbnailStorage});

router.post("/upload-music", uploadFile.single("file"), uploadThumbnail.single("thumbnail"),uploadMusic);
router.get("/get-music-files", getMusicFiles);
export default router;
