import bodyParser from "body-parser";
import express from "express";
import multer from "multer";
import { GridFsStorage } from "multer-gridfs-storage";
import methodOverride from "method-override";
import { uploadMusic, getSingleMusicFile,getMusicFiles, getMusicByCategory, myFavourite } from "../controllars/music.js";
const router = express.Router();
const app = express();
// Middleware
router.use(express.json()); // Instead of bodyParser.json()
app.use(methodOverride("_method"));

// Mongo URI
const mongoURI = "mongodb://localhost:27017/mern-music-app";

const storage = new GridFsStorage({
  url: mongoURI,
  file: (req, file) => {
    console.log(file);
    return new Promise((resolve, _reject) => {
      const fileInfo = {
        filename: file.originalname,
        bucketName: "filesBucket",
      };
      resolve(fileInfo);
    });
  },
});

const upload = multer({ storage });
router.post("/upload-music", upload.single("file"), uploadMusic);
// router.post("/upload-thumbnail", upload.single("thumbnail"), uploadMusic);
router.get("/get-single-music-file/:id", getSingleMusicFile);

router.get("/get-music-files", getMusicFiles);
router.get("/get-music-by-category/:category", getMusicByCategory);
router.get("/get-my-favourite-music/:IDs", myFavourite);



export default router;
